import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5fec2c92 = () => interopDefault(import('..\\pages\\cv.vue' /* webpackChunkName: "pages/cv" */))
const _39eddbfa = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'form__btn--active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/cv",
    component: _5fec2c92,
    name: "cv"
  }, {
    path: "/de",
    component: _39eddbfa,
    name: "index___de"
  }, {
    path: "/en",
    component: _39eddbfa,
    name: "index___en"
  }, {
    path: "/es",
    component: _39eddbfa,
    name: "index___es"
  }, {
    path: "/fr",
    component: _39eddbfa,
    name: "index___fr"
  }, {
    path: "/pt",
    component: _39eddbfa,
    name: "index___pt"
  }, {
    path: "/de/cv",
    component: _5fec2c92,
    name: "cv___de"
  }, {
    path: "/en/cv",
    component: _5fec2c92,
    name: "cv___en"
  }, {
    path: "/es/cv",
    component: _5fec2c92,
    name: "cv___es"
  }, {
    path: "/fr/cv",
    component: _5fec2c92,
    name: "cv___fr"
  }, {
    path: "/pt/cv",
    component: _5fec2c92,
    name: "cv___pt"
  }, {
    path: "/",
    component: _39eddbfa,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
