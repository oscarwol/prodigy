import { globalPlugin } from '@nuxtjs/composition-api'

export default globalPlugin
