import './register.js'
import middleware from '../middleware.js'

export default middleware
