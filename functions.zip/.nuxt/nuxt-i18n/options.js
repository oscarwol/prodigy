

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
  REDIRECT_ON_OPTIONS: {"ALL":"all","ROOT":"root","NO_PREFIX":"no prefix"},
}
export const nuxtOptions = {
  isUniversalMode: true,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {},
  vueI18nLoader: false,
  locales: [{"code":"en","file":"en.json","name":"English"},{"code":"es","file":"es.json","name":"Español"},{"code":"fr","file":"fr.json","name":"French"},{"code":"de","file":"de.json","name":"German"},{"code":"pt","file":"pt.json","name":"Portuguese"}],
  defaultLocale: "es",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "prefix",
  lazy: true,
  langDir: "C:\\Users\\omorales\\Desktop\\Prodigy\\lang",
  rootRedirect: null,
  detectBrowserLanguage: {"alwaysRedirect":false,"cookieCrossOrigin":false,"cookieDomain":null,"cookieKey":"i18n_redirected","cookieSecure":false,"fallbackLocale":"","redirectOn":"root","useCookie":true,"onlyOnRoot":true},
  differentDomains: false,
  baseUrl: "",
  vuex: {"moduleName":"i18n","syncRouteParams":true},
  parsePages: true,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"code":"en","file":"en.json","name":"English"},{"code":"es","file":"es.json","name":"Español"},{"code":"fr","file":"fr.json","name":"French"},{"code":"de","file":"de.json","name":"German"},{"code":"pt","file":"pt.json","name":"Portuguese"}],
  localeCodes: ["en","es","fr","de","pt"],
}

export const localeMessages = {
  'en.json': () => import('../..\\lang\\en.json' /* webpackChunkName: "lang-en.json" */),
  'es.json': () => import('../..\\lang\\es.json' /* webpackChunkName: "lang-es.json" */),
  'fr.json': () => import('../..\\lang\\fr.json' /* webpackChunkName: "lang-fr.json" */),
  'de.json': () => import('../..\\lang\\de.json' /* webpackChunkName: "lang-de.json" */),
  'pt.json': () => import('../..\\lang\\pt.json' /* webpackChunkName: "lang-pt.json" */),
}
